﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace pr14_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string text = textBox1.Text;
                if (string.IsNullOrWhiteSpace(text))
                {
                    MessageBox.Show("Введите текст!");
                    return;
                }

                File.WriteAllText("t.txt", text);
                MessageBox.Show("текст сохранен!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка!");
            }
        }

        private string CheckBalance(string expr)
        {
            Stack<int> posStack = new Stack<int>();
            bool isBalan = true;
            string result = "";

            for (int idx = 0; idx < expr.Length; idx++)
            {
                char symb = expr[idx];

                if (symb == '(')
                {
                    posStack.Push(idx);
                }
                else if (symb == ')')
                {
                    if (posStack.Count == 0)
                    {
                        result = $"Возможно лишняя ) скобка в позиции: {idx}";
                        isBalan = false;
                        break;
                    }
                    else
                    {
                        posStack.Pop();
                    }
                }
            }

            if (isBalan)
            {
                if (posStack.Count == 0)
                {
                    result = "скобки сбалансированы";
                }
                else
                {
                    int firstUncl = posStack.Pop();
                    result = $"Возможно лишняя ( скобка в позиции: {firstUncl}";
                }
            }

            return result;
        }

        private string FixBrackets(string expr)
        {
            Stack<int> openPos = new Stack<int>();
            List<int> extraPos = new List<int>();

            for (int idx = 0; idx < expr.Length; idx++)
            {
                char symb = expr[idx];

                if (symb == '(')
                {
                    openPos.Push(idx);
                }
                else if (symb == ')')
                {
                    if (openPos.Count == 0)
                    {
                        extraPos.Add(idx);
                    }
                    else
                    {
                        openPos.Pop();
                    }
                }
            }

            string tempExpr = expr;
            for (int cnt = extraPos.Count - 1; cnt >= 0; cnt--)
            {
                tempExpr = tempExpr.Remove(extraPos[cnt], 1);
            }

            string fixedExpr = tempExpr;
            int openCnt = 0;

            foreach (char symb in tempExpr)
            {
                if (symb == '(') openCnt++;
                else if (symb == ')') openCnt--;
            }

            for (int cnt = 0; cnt < openCnt; cnt++)
            {
                fixedExpr += ")";
            }

            return fixedExpr;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists("t.txt"))
                {
                    MessageBox.Show("Файл t.txt не найден. Сначала запишите выражение.");
                    return;
                }

                string expr = File.ReadAllText("t.txt");

                string balan = CheckBalance(expr);
                label1.Text = balan;

                string fixedExpr = FixBrackets(expr);
                File.WriteAllText("t1.txt", fixedExpr);

                MessageBox.Show($"Исправленное выражение сохранено в файл t1.txt\n\n" +
                    $"Исходное: {expr}\nИсправленное: {fixedExpr}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}
